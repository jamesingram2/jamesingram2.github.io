# frontEndProject
About The Project
Product Name: CyptoWatcher

This app was designed to keep you up to date, with all things Crypto!





Built With

Bootstrap


Getting Started
Go to app or site and indulge in all the latest crypto news.





Get a free API Key at https://apipheny.io/free-api/
Clone the repo
git clone https://github.com/jamesingram2/frontEndProject
Install NPM packages
npm install
Enter your API in config.js
const API_KEY = 'ENTER YOUR API';



For more examples, please refer to the Documentation


Roadmap
 Add Changelog
 Add back to top links
 Add Additional Templates w/ Examples
 Add "components" document to easily copy & paste sections of the readme

See the open issues for a full list of proposed features (and known issues).




If you have a suggestion that would make this better, please fork the repo and create a pull request. You can also simply open an issue with the tag "enhancement". Don't forget to give the project a star! Thanks again!

Fork the Project
Create your Feature Branch (git checkout -b feature/AmazingFeature)
Commit your Changes (git commit -m 'Add some AmazingFeature')
Push to the Branch (git push origin feature/AmazingFeature)
Open a Pull Request


License
See LICENSE.txt for more information.



Contact- James Ingram jamesingram.tech@gmail.com
Jesse Henley xwritecodex@gmail.com
Nina Moyer  ninacoral@gmail.com

Project Link: https://github.com/jamesingram2/frontEndProject


(back to top)
